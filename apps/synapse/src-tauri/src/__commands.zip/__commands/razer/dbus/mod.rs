mod daemon_interface;
mod device_interface;
mod devices_interface;

use std::collections::HashMap;

// use crate::commands::device::Device;
use crate::commands::razer::dbus::daemon_interface::DaemonInterfaceProxy;
use crate::commands::razer::dbus::device_interface::{
    build_DeviceInterfaceProxyVec, DeviceInterfaceProxy,
};
use crate::commands::razer::dbus::devices_interface::DevicesInterfaceProxy;
use crate::commands::razer::razer_trait::RazerTrait;
use zbus::Connection;

pub struct DBusImpl<'a> {
    daemon: DaemonInterfaceProxy<'a>,
    devices: DevicesInterfaceProxy<'a>,
    device: HashMap<String, DeviceInterfaceProxy>,
}

impl<'a> DBusImpl<'a> {
    pub async fn new() -> Self {
        let connection = Connection::session().await.unwrap();
        let daemon = DaemonInterfaceProxy::new(&connection).await.unwrap();
        let devices = DevicesInterfaceProxy::new(&connection).await.unwrap();

        let identifiers = devices.getDevices().await.unwrap();

        let device = identifiers
            .into_iter()
            .map(|id| {
                let device_proxy = build_DeviceInterfaceProxyVec(&connection, &id);
                (device_proxy.id.clone(), device_proxy)
            })
            .collect();

        DBusImpl {
            daemon,
            devices,
            device,
        }
    }
}

use crate::commands::device::Device;

impl<'a> RazerTrait for DBusImpl<'a> {
    fn stop(&self) {
        // match self.daemon.stop().await {
        //     Ok(result) => result,
        //     Err(_) => "Error calling Zbus".into(),
        // }
    }

    fn devices(&self) -> Vec<String> {
        // match self.devices.getDevices().await {
        //     Ok(result) => result,
        //     Err(_) => "Error calling Zbus".into(),
        // }
        vec![]
    }

    // fn device_info(&self, id: &String) -> Device {
    //     // ?
    //     //
    //   {
    //
    //   }
    // }
}
