use zbus::Connection;

const RAZER_BUS_NAME: &str = "org.razer";
const RAZER_DEVICE_BASEPATH: &str = "/org/razer/device/";
const INTROSPECT_INTERFACE: &str = "org.freedesktop.DBus.Introspectable";

pub struct DeviceInterfaceProxy {
    pub id: String,
    connection: Connection,
    device_path: String,
}

pub fn build_DeviceInterfaceProxyVec(
    connection: &Connection,
    serial: &String,
) -> DeviceInterfaceProxy {
    DeviceInterfaceProxy {
        id: serial.clone(),
        connection: connection.clone(),
        device_path: format!("{}{}", RAZER_DEVICE_BASEPATH, serial),
    }
}

impl DeviceInterfaceProxy {
    async fn get_device_name(&self) -> String {
        let m = self
            .connection
            .call_method(
                Some("org.razer"),
                // "/org/razer/device/352006H13252288",
                self.device_path.clone(),
                Some("razer.device.misc"),
                // Some(interface),
                "getDeviceName",
                &(),
            )
            .await;

        let reply: String = m.unwrap().body().deserialize().unwrap();
        println!("{}", reply.clone());

        reply
    }
}
