use zbus::proxy;

#[proxy(default_service = "razer.daemon", default_path = "/org/razer")]
pub trait DaemonInterface {
    async fn stop(&self) -> zbus::Result<()>;
    async fn version(&self) -> zbus::Result<String>;
}
