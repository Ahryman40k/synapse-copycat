use zbus::proxy;

#[proxy(
    default_service = "org.razer",
    default_path = "/org/razer",
    interface = "razer.devices"
)]
pub trait DevicesInterface {
    #[zbus(signal)]
    fn device_removed(&self, arg1: &str, arg2: u32) -> fdo::Result<()>;

    #[zbus(signal)]
    fn device_added(&self, arg1: &str, arg2: u32) -> fdo::Result<()>;

    async fn getDevices(&self) -> zbus::Result<Vec<String>>;
    async fn supportedDevices(&self) -> zbus::Result<String>;
}
