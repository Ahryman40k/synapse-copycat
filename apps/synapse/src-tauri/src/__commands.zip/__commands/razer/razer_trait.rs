use crate::commands::device::Device;

pub trait RazerTrait {
    fn stop(&self) -> ();
    fn devices(&self) -> Vec<String>;
    // fn device_info(&self, id: &String) -> Device;
}
