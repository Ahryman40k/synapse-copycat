mod dbus;
mod razer_trait;

use crate::commands::{device::Device, razer::razer_trait::RazerTrait};
use tokio::runtime::Runtime;

pub struct Razer {
    inner: Box<dyn RazerTrait>,
}

impl Razer {
    pub fn new() -> Self {
        let rt = Runtime::new().unwrap();
        let inner = rt.block_on(dbus::DBusImpl::new());
        Razer {
            inner: Box::new(inner),
        }
    }

    pub fn stop(&self) -> () {
        self.inner.stop();
    }

    pub fn devices(&self) -> Vec<String> {
        self.inner.devices()
    }

    // pub fn device_info(&self, id: &String) -> Device {
    //     self.inner.device_info(id)
    // }
}

#[cfg(test)]
mod tests {
    use super::*;
}
