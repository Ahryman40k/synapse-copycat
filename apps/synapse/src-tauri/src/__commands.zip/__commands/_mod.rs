mod device;

use device::Device;

mod module;
use module::Module;

use crate::commands::{device::DeviceKind, razer::Razer};

mod razer;
mod twinkly;

#[tauri::command]
pub fn devices() -> Vec<Device> {
    // let razer = Razer::new();
    // let identifiers = razer.devices();

    // identifiers.iter().map(|id| razer.device_info(id)).collect()

    vec![Device {
        kind: DeviceKind::Mouse,
        vendor_id: 1111,
        product_id: 6666,
        name: "MouseLove ".to_string(),
    }]
}

#[tauri::command]
pub fn modules() -> Vec<Module> {
    vec![]
}

#[tauri::command]
pub fn runCapability(capability: String, device: Device) -> () {}
